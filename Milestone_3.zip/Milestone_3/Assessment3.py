# STEP 0(a): Let's connect to mongo DB
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
# STEP 0(b): Let's access pandas for data format
import pandas as pd
# STEP 0(c): Temp csv file storage to avoid type mismatch
import csv
# STEP 0(d): Final Output storage in sqlite
import sqlite3
def MongoCloudToSqlitelocalDB(MongoConn,TempcsvFile,SqliteConn):
    #STEP 1: sqlite connection
    connection = sqlite3.connect(SqliteConn)
    curr = connection.cursor()
    # print(curr)
    # STEP 2: DROP table if already exists
    curr.execute("DROP TABLE IF EXISTS movies_output1")
    # STEP 3: CREATE TABLE IF NOT EXISTS
    curr.execute("""
       CREATE TABLE IF NOT EXISTS movies_output1(
       _id	INTEGER,
       plot TEXT,	
       genres TEXT,
       runtime INTEGER,
       cast TEXT,
       poster TEXT,
       title TEXT,
       fullplot	TEXT,
       languages TEXT,
       released	TEXT,
       directors TEXT,
       rated TEXT,
       awards TEXT,
       lastupdated	DATETIME,
       year	INTEGER,
       imdb	TEXT,
       countries TEXT,
       type	TEXT,
       tomatoes	TEXT,
       num_mflix_comments INTEGER,
       writers	TEXT,
       metacritic TEXT
       )
""")

    # STEP 4: CREATE MONGO DB CONNECTION
    # uri = r"mongodb+srv://vaigainatarajan:yzenoBqY8268Wb10@cluster0.93wxh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
    uri=MongoConn

    # STEP 5: READING MONGO COLLECTION 'movies' AND SAVE IT IN DATA FRAME
    try:    
        client = MongoClient(uri,server_api =ServerApi('1'),tlsallowinvalidcertificates=True)
        client.admin.command("ping")
        db = client['sample_mflix']
        collection =db['movies']
        results=collection.find()
        df = pd.DataFrame(results)
        # print("Actual Mongo DB",df)
        # print(df.columns)    
    # STEP 6: CONVERTING DATA FRAME into CSV FILE
        final_df = df.to_csv(TempcsvFile,sep=",",encoding="utf-8",header=True,index=False)
        # print(final_df)
    # STEP 7: INSERTING VALUES INTO SQLITE using CSV values
        csv_file = open(TempcsvFile)
        csv_content = csv.reader(csv_file)
        insert_records="""
                   INSERT INTO movies_output1 (
                   _id,
       plot ,	
       genres ,
       runtime ,
       cast ,
       poster ,
       title ,
       fullplot	,
       languages ,
       released	,
       directors ,
       rated ,
       awards ,
       lastupdated	,
       year	,
       imdb	,
       countries ,
       type	,
       tomatoes	,
       num_mflix_comments ,
       writers	,
       metacritic 
                   ) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                   
        """  
        curr.executemany(insert_records,csv_content)
    # STEP 8 : VALIDATING SQLITE DATA used SELECT
        select_values = "SELECT * FROM movies_output1"
        rows = curr.execute(select_values).fetchall()
        print(rows)
        # for r in rows:
        #     print(r)
    
    # STEP 9 : SAVING DB CHANGES
        connection.commit()
    # STEP 10 : TERMINATING DB CONNECTION
        connection.close()
   
    except Exception as e:
        print(e)

# |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
#Invoking
param_SqliteConn=r"C:\Users\Administrator\OneDrive\Desktop\UST Training\Milestone_3\finaloutput.sqlite"
param_Temp=r"C:\Users\Administrator\OneDrive\Desktop\UST Training\Milestone_3\temp.csv"
param_MongoDBSoure=r"mongodb+srv://vaigainatarajan:yzenoBqY8268Wb10@cluster0.93wxh.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"

MongoCloudToSqlitelocalDB(param_MongoDBSoure,param_Temp,param_SqliteConn)
# |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||